package mind.core.program;
abstract class MNC{
	MNC()
	{
		System.out.println("This is parent class");
	}
	public void display()
	{
		System.out.println("welcome to parent class");
	}
	abstract void leaves();
	abstract void holidays();
}
abstract class Mindsprint extends MNC
{
	public void holidays()
	{
		System.out.println("There is holiday on 14th March due to Holi");
	}
	abstract void leaves();
}
class Hello extends Mindsprint{
	public void leaves()
	{
		System.out.println("You can take leave upto 36days in a years");
	}
	public void holidays()
	{
		System.out.println("There will holiday on 31st march");
	}
	public void unpaid_leaves()
	{
		System.out.println("If you take leave without informing,it will considered as unpaid leave");
	}
}
public class AbstractionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MNC h1=new Hello();
		h1.holidays();
		h1.leaves();
//		h1.unpaid_leaves();
	}

}
