package mind.core.program;

public class Function_Overloading {

	public void area(int l,int b)
	{
		System.out.println("area of rectangle:"+l*b);
	}
	public void area(float radius)
	{
		System.out.println("area of circle:"+3.14*radius*radius);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function_Overloading f1=new Function_Overloading();
		f1.area(10,20);
		f1.area(10);
	}

}
