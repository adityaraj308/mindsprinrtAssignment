package mind.core.program;
import java.util.*;
public class AssignmentCollection3 {

	public static void main(String[] args) {
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("Pomegrant");
		a1.add("Orange");
		a1.add("Papaya");
		a1.add("Guava");
		a1.add("Banana");
		a1.add("Apple");
		a1.add("Kolkata");
		a1.add("Chennai");
		a1.add("Playing Cricket");
		a1.add("Listen to music");
		System.out.println("Array List is:"+a1);
		a1.remove("Playing Cricket");
		System.out.println("Array List after removing one hobby is:"+a1);
		System.out.println(a1.contains("cricket"));
		a1.remove("Orange");
		a1.remove("Chennai");
		System.out.println("Array List after removing 1city and 1fruit is:"+a1);
		a1.add("Singing");
		System.out.println("New Array List is:"+a1);
		System.out.println(a1.size());
		a1.set(7, "Dancing");
		System.out.println("Array List after replacing is:"+a1);
		a1.reversed();
		System.out.println("Reversed Array List is:"+a1);
		a1.set(4, "Kerala");
		a1.set(2, "Mango");
		System.out.println("After operation Array List is:"+a1);
		
		System.out.println("Sub Array List is:"+a1.subList(2, 6));
	}

}
