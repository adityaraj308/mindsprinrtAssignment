package mind.core.program;
class Product
{
	public int id=78;
	public String name="Amul";
	public void display()
	{
		System.out.println("id:"+id+" name:"+name);
	}
}
class A extends Product
{
	public int count=50;
	public String category="butter";
	public void display()
	{
		System.out.println("product id:"+id+" product name:"+name+" product category:"+category);
		System.out.println("product count:"+count);
	}
}
class subA extends A
{
	public int price=30;
	int total_price=count*price;
	public void display()
	{
		System.out.println("product id:"+id+" product name:"+name+" +product category:"+category);
		System.out.println("total price:"+total_price);
	}
}
class B extends Product
{
	public int count=90;
	public String category="milk";
	public void display()
	{
		System.out.println("product id:"+id+" product name:"+name+" product category:"+category);
	}
}
class subB extends B
{
	public int price=10;
	int total_price=count*price;
	public void display()
	{
		System.out.println("product id:"+id+" product name:"+name+" product category:"+category);
		System.out.println("total price:"+total_price);
	}
}
class C extends Product
{
	public int count=56;
	public String category="choco";
	public void display()
	{
		System.out.println("product id:"+id+" product name:"+name+" product category:"+category);
	}
}
public class Inheritance {

	public static void main(String[] args) {
//		Product p1=new Product();
//		p1.display();
		subA sub1=new subA();
		sub1.display();
		subB sub2=new subB();
		sub2.display();
		C c1=new C();
		c1.display();
	}

}
