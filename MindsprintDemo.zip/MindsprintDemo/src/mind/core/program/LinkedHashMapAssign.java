package mind.core.program;
import java.util.LinkedHashMap;
import java.util.Map;
public class LinkedHashMapAssign {

	public static void main(String[] args) {
		LinkedHashMap<Integer,String> lhm=new LinkedHashMap<Integer,String>();
		lhm.put(91,"India");
		lhm.put(92, "Singapore");
		lhm.put(93, "USA");
		lhm.put(94, "Russia");
		lhm.put(95, "Japan");
		lhm.put(96,"Australia");
		lhm.put(97, "Thailand");
		lhm.put(98, "France");
		lhm.put(99, "Nepal");
		lhm.put(89, "Srilanka");
		for(Integer key:lhm.keySet())
		{
			System.out.println("key:"+lhm.get(key));
		}
		System.out.println(lhm.containsValue("India"));
		System.out.println(lhm.containsKey(45));
		lhm.remove(95);
		System.out.println(lhm);
		LinkedHashMap<Integer,String> st=new LinkedHashMap<Integer,String>();
		st.put(1,"Bihar");
		st.put(2, "Uttar Pradesh");
		st.put(3,"West Bengal");
		st.put(4, "Jharkhand");
		st.put(5, "Tamilnadu");
		System.out.println(st);
		lhm.putAll(st);
		System.out.println(lhm);
		lhm.remove(5);
		System.out.println(lhm.isEmpty());
		lhm.clear();
		System.out.println(lhm);
	}
}
