package mind.core.program;
import java.util.HashSet;
import java.util.TreeSet;
public class CollectionDemo{
 
	public static void main(String[] args) {
		HashSet hs = new HashSet();
		hs.add(340);
		hs.add(true);
		hs.add('H');
		hs.add(560.00f);
		hs.add(5000.00);
		hs.add("India");
		hs.add(new String("Java"));
		System.out.println(" the hashset is " + hs);
		System.out.println(hs.contains("India"));
		System.out.println(hs.remove(340));
		System.out.println(" the hashset is " + hs);
		System.out.println(hs.size());
		System.out.println(hs.isEmpty());
	    hs.clear();
		System.out.println(" the hashset is " + hs);
//		HashSet<String> hsnew = new HashSet<String>();
//		hsnew.add("India");
//		hsnew.add(new String("Java"));
//		hsnew.add("Sri Lanka");
//		hsnew.add("Europe");
//		hsnew.add("Austriaia");
//		hsnew.add("HTML");
//		hsnew.add("Python");
//		System.out.println(" the hashset is " + hsnew);
		TreeSet<String> hsnew = new TreeSet<String>();
		hsnew.add("India");
		hsnew.add(new String("Java"));
		hsnew.add("Sri Lanka");
		hsnew.add("Europe");
		hsnew.add("Austriaia");
		hsnew.add("HTML");
		hsnew.add("Python");
		System.out.println(" the hashset is " + hsnew);
	}
}