package mind.core.program;

public class ModifierExample {
	public int sum(int a,int b)
	{
		int result=a+b;//local variable result
		return result;
	}
	public void display()
	{
		System.out.println("This is display method");
	}
	public static void main(String[] args) {
		
		int age=78;
		String name="Ram";
		boolean status=false;
		char stat='p';
		long salary=45678923L;
		double h=567894.500;
		System.out.println("the age is"+ age);
		System.out.println("my name is"+ name+" and salary is :"+salary);
		ModifierExample mf=new ModifierExample();
		mf.display();
		System.out.println("the sum is :"+mf.sum(10, 20));
	}

}
