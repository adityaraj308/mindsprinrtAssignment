package mind.core.program;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;
public class AssignmentLinkedList {

	public static void main(String[] args) {
		
		LinkedList<String> ll=new LinkedList<String>();
		
		ll.add("May");
		ll.add("June");
		ll.add("July");
		ll.add("August");
		ll.add("April");
		ll.add("November");
		
		System.out.println(ll);
		
		ll.addLast("December");
		ll.addFirst("January");
		ll.add("March");
		ll.add(1,"February");
		ll.add("September");
		ll.add(9,"October");
		
		System.out.println(ll);

		ll.set(0, "Januray");
		ll.set(1, "Februray");
		ll.set(2, "March");
		ll.set(3, "April");
		ll.set(4, "May");
		ll.set(5, "June");
		ll.set(6, "July");
		ll.set(7, "August");
		ll.set(8, "September");
		ll.set(9, "October");
		ll.set(10, "November");
		ll.set(11, "December");
		System.out.println(ll);
		System.out.println("Even Months:");
		for(int i=0;i<12;i++)
		{
			if(i%2!=0)
			{
				System.out.println(ll.get(i));
			}
		}
		System.out.println("Odd Months:");
		for(int i=0;i<12;i++)
		{
			if(i%2==0)
			{
				System.out.println(ll.get(i));
			}
		}
		Iterator itr=ll.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("First Month:"+ll.getFirst()+", last month"+ll.getLast());
		ll.remove("August");
		System.out.println("After removing my birthday:"+ll);
		System.out.println(ll.contains("December"));
		System.out.println("Using peek First month:"+ll.peekFirst()+" ,last month:"+ll.peekLast());
		ll.pollFirst();
		ll.pollLast();
		System.out.println("After removing first and last"+ll);
	}

}
