package mind.core.program;
import java.util.Scanner; 
public class Calculator {

	public int calculate(int x,int y)
	{
		int sum=x+y;
		return sum;
	}
	public long calculate(long x,long y)
	{
		long sub=x-y;
		return sub;
	}
	public float calculate(float x,float y)
	{
		float mul=x*y;
		return mul;
	}
	public double calculate(double x,double y)
	{
		double div=x/y;
		return div;
	}
	public void isEven(int a)
	{
		if(a%2==0)
		{
			System.out.println(a+"is a even number");
		}
		else
		{
			System.out.println(a+"is a odd number");
		}
	}
	public void isPrime(int x)
	{
		boolean f=false;
		if(x==0||x==1)
		{
			f=true;
		}
		for(int i=2;i<=x/2;++i)
		{
			if(x%i==0)
			{
				f=true;
				break;
			}
		}
		if(!f)
		{
			System.out.println(x+"is a prime number");
		}
		else
		{
			System.out.println(x+"is a composite number");
		}
	}
	public static void main(String[] args) {
		Calculator c1=new Calculator();
		System.out.println("Sum of two number is:"+ c1.calculate(5,6));
		System.out.println(c1.calculate(10l, 5l));
		System.out.println("Multiplication of two number is"+c1.calculate(6f,7f));
		System.out.println("Divison of two number is"+c1.calculate(30.00,6.00));
		c1.isEven(632);
		c1.isPrime(13);
	}

}
