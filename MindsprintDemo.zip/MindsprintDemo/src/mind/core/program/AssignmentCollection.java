package mind.core.program;
import java.util.LinkedHashSet;
import java.util.Scanner;
public class AssignmentCollection {

	public static void main(String[] args) {
		LinkedHashSet lhs=new LinkedHashSet();
		lhs.add(5);
		lhs.add(10);
		lhs.add(15f);
		lhs.add(5f);
		lhs.add("India");
		lhs.add("Python");
		lhs.add(true);
		System.out.println("LinkedHashSet is:"+lhs);
		LinkedHashSet l2=new LinkedHashSet();
		l2.add(183);
		Scanner myObj = new Scanner(System.in);
		for(int i=0;i<10;i++)
		{
			int num=myObj.nextInt();
			l2.add(num);
		}
		System.out.println("LinkedHashSet 2:"+l2);
		lhs.add("java");
		lhs.add("c++");
		lhs.remove("India");
		System.out.println(lhs.contains("INdia"));
		System.out.println(lhs.contains(5));
		lhs.clear();
		System.out.println("After operation LinkedHashedSet1 is:"+lhs);
		
	}

}
