package mind.core.program;
import java.util.TreeSet;

public class AssignmentCollection2 {

	public static void main(String[] args) {
		TreeSet t1=new TreeSet();
		t1.add("Python");
		t1.add("java");
		t1.add("c++");
		t1.add("Ruby");
		t1.add("R");
		t1.add("javascript");
		System.out.println("TreeSet is:"+t1);
		t1.remove("Ruby");
		t1.remove("java");
		System.out.println("After removal of two language:"+t1);
		t1.add("c#");
		t1.add("c");
		t1.add("HTML");
		System.out.println("TreeSet after adding is:"+t1);
		System.out.println(t1.contains("Java"));
		t1.clear();
		System.out.println("TreeSet is:"+t1);
		
	}

}